#!/bin/bash
#-------------------------------------------------------------------------------------------------------------------
#   CONGIG SECTION
#-------------------------------------------------------------------------------------------------------------------

user="flibusta"
pass="flibusta"

script_path=$(dirname $(realpath "$0"))

tmp_path="$script_path/tmp"

sql_path_fb="$script_path/sql_fb"
sql_path_es="$script_path/sql_es"

result_path="$script_path/update"


name_fb="extra_flibusta_online_fb2"
name_es="extra_librusec_online_fb2"


tables_fb="lib.libavtor lib.libavtorname lib.libbook lib.libgenre lib.libgenrelist lib.librate lib.libseqname lib.libseq"
tables_es="libavtor libavtors libbook libgenre libgenres libmag libmags libpolka libquality librate libseq libseqs"

url=http://flibustaongezhld6dibs2dps6vm4nvqg2kp7vgowbu76tzopgnhazqd.onion/sql
#url=https://flibusta.is/sql
url_es=http://lib.rus.ec/sql

timeout_sec=90