#!/bin/bash

BASEDIR=$(dirname $0)
echo "BASEDIR is $BASEDIR"

cd $BASEDIR


./extra_download_bases.sh
./extra_import_bases.sh
./extra_gen_daily.sh
