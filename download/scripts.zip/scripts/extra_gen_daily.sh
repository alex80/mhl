#!/bin/bash
#-------------------------------------------------------------------------------------------------------------------
#  Generate daily update
#-------------------------------------------------------------------------------------------------------------------

source config.sh


cd $tmp_path
rm -v $tmp_path/*

rm $result_path/$name_fb.*

php $script_path/extra_gen_daily_flibusta.php $user $pass $result_path $name_fb

chown www-data $result_path/$name_fb.*
chmod 666 $result_path/$name_fb.*



#------------------------------------------------------------------------------------------------------------------------------------------

#
#    rm $result_path/$name_es.*

#    php $script_path/extra_gen_daily_librusec.php $user $pass $result_path $name_es
#
#    chown www-data $result_path/$name_es.*
#    chmod 666 $result_path/$name_es.*
#

