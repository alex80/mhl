<?php
	echo "Текущая версия PHP: ".phpversion().chr(10);
	$dblocation = "localhost";   
	$dbname = "librusec";   
	$dbuser = $argv[1];   
	$dbpasswd = $argv[2];   

	$dbcnx = mysqli_connect($dblocation, $dbuser, $dbpasswd);   
	if (!$dbcnx)   
	{   
		echo "<p>Не удалось подключиться к mySQL</p>";   
		exit();   
	}   
	if (!mysqli_select_db($dbcnx,$dbname) )   
	{   
		echo "<p>Проблемы с БД  :-(</p>";   
		exit();   
	}

	mysqli_query($dbcnx,"SET NAMES 'utf8';");

// --------------------------------------------------------------
// последний ID в librusec_online_fb2.inpx
//$Start = 736789;    
$Start = 753916;    
// --------------------------------------------------------------

        $filename = "extra.inp";

	$mode = "w-";
	$sep = chr(4);	

	mysqli_query($dbcnx,"SET NAMES 'utf8';");
	$query = "SELECT `bid`,`Title`,`FileSize`,`FileType`,`Deleted`,`Time`,`Lang`,`keywords` FROM libbook WHERE bid>=".$Start." AND FileType='fb2';";
	$q_book_list = mysqli_query($dbcnx,$query);

	$f = fopen ($filename, $mode, $use_other_path=false);
        $i = 0; 
	fwrite($f, pack("CCC",0xef,0xbb,0xbf));

	echo "LibRuSec. Generation of extra-book list is started".chr(10);

	while ($book = mysqli_fetch_array($q_book_list))
	{
		
		$FileName = $book[0];
		$Ext = "fb2";
		$BookId=$book[0];
		
		$query = "select an.LastName, an.FirstName, an.MiddleName from libavtor ba join libavtors an on an.aid = ba.aid WHERE  ba.bid=".$BookId.";";

		$avt_out="";
		$q_avtor_id_list = mysqli_query($dbcnx,$query);
		if ($q_avtor_id_list)
		{
			while ($avtor=mysqli_fetch_array($q_avtor_id_list))
				$avt_out=$avt_out.$avtor[0].",".$avtor[1].",".$avtor[2].":";
			$avt_out=$avt_out.$sep;
		}
	
		//---------------------   Добываем список жанров  --------------------------------------------------------------
		$query = "SELECT G.code FROM libgenres G, libgenre GL Where GL.bid = ".$BookId." AND G.gid = GL.gid;";
		$genre_id_list=mysqli_query($dbcnx,$query);
		if ($genre_id_list)
		{
			$genres_out="";
			while ($genre_code=mysqli_fetch_array($genre_id_list))
				$genres_out=$genres_out.$genre_code[0].":";
		} 
		else 
			$genres_out="other:";	

		//---------------------------   список серий   ------------------------------------------
		$query = "SELECT S.seqname, SL.sid, SL.sn FROM libseqs S, libseq SL Where SL.bid = ".$BookId." AND S.sid = SL.sid;";
		$q_seq = mysqli_query($dbcnx,$query);
		if ($q_seq)
		{
			$seq = mysqli_fetch_row($q_seq);
// Сыпятся ошибки PHP Notice:  Trying to access array offset on value of type null
// т.к. $seq аозвращает пустой массив, и $seq[0] отсутствует,
// но обновления генерятся нормально
// Если добавить проверку if (isset($seq)) то обновления неправильно создаются
// Или надо создавать обновления с php 7.3 и ниже
// -------------------------------------------------------------------------------
			if (isset($seq))
			{
			    $seq_out=$seq[0];
			    $SeqNumber=floor($seq[2]);
			}
			else
			{
			    $seq_out="";
			    $SeqNumber=0;
			}
// -------------------------------------------------------------------------------
		}	
		else
		{		
			$seq_out="";
			$SeqNumber=0;
		}	

		//---------------------------- все остальное -----------------------------------
		$sdate=substr($book[5],0,strpos($book[5]," "));
		
		if (strlen($avt_out) < 4) $avt_out="неизвестный,автор,:".$sep;
	
		// SELECT `BookId`,`Title`,`FileSize`,`FileType`,`Deleted`,`Time`,`Lang`,`N`,`keywords`	
			
		//	авторы;	жанры;	название;	серия;	номер в серии;
		$out = $avt_out.$genres_out.$sep.$book[1].$sep.$seq_out.$sep.$SeqNumber;
		//	имя файла;	размер файла;	LibId;	Deleted;
		$out.=$sep.$FileName.$sep.$book[2].$sep.$book[0].$sep.$book[4];
		//	тип файла;	дата;	язык;	keywords;
		$out.=$sep.$Ext.$sep.$sdate.$sep.$book[6].$sep.$sep.$book[7].$sep;
		
		$out = str_replace(chr(13),"",$out);
		$out = str_replace(chr(10),"",$out);
		
		$out = $out.chr(13).chr(10);		
		
		fwrite($f, $out);
		$i ++;
	}
	fclose($f);

	if ($i < 5)
	{ 
		echo "no records!";
		exit();
	}
	
	$f = fopen ("version.info", $mode, $use_other_path=false);

/*	$today = getdate();
//	$today = getdate(strtotime("-1 day"));

	$day = $today["mday"];
	$mon = $today["mon"];
	
	if ($day < 10) 
	{
		$sday = "0".$day;
	}
	else $sday = $day;
	
	if ($mon < 10) 
	{
		$smon = "0".$mon;
	}
	else $smon = $mon;
	
   	$out = $today["year"].$smon.$sday;
*/
	$out = date("Ymd", strtotime("-1 day"));
	echo "Update date:".$out."\n";
	fputs($f, $out);
	fclose($f);
	copy("version.info", $argv[3]."/".$argv[4].".info");

	$f = fopen ("$filename".".ver", $mode, $use_other_path=false);
	$ver = date("Y-m-d", strtotime("-1 day"));	
	fputs($f, $ver);
	fclose($f);
	copy("$filename".".ver", $argv[3]."/".$argv[4].".ver");
	

	echo $i." records processed.\n";
	echo "Done.\n";


	$zip = new ZipArchive();
	$zipfilename = $argv[3]."/".$argv[4].".zip";
	
	if ($zip->open($zipfilename, ZIPARCHIVE::CREATE)!==TRUE) {
		exit("cannot open <$filename>\n");
	}
	$zip->addFile($filename);
	$zip->addFile("version.info");
	echo "Zip numfiles: " . $zip->numFiles . "\n";
	echo "Zip status:" . $zip->status . "\n";
	$zip->close();	
?>