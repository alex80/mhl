#!/bin/bash
#-------------------------------------------------------------------------------------------------------------------
#  Import bases
#-------------------------------------------------------------------------------------------------------------------

source config.sh


gunzip -fv $sql_path_fb/*.sql.gz
gunzip -fv $sql_path_es/*.sql.gz

for i in $tables_fb
do
	mysql --user=$user --password=$pass --database=flibustanet < $sql_path_fb/$i.sql
#	mysql --login-path=flibusta -D flibustanet < $sql_path_fb/$i.sql
done


#for i in $tables_es
#do
#	mysql --user=$user --password=$pass --database=librusec < $sql_path_es/$i.sql
#	mysql --login-path=flibusta -D librusec < $sql_path_es/$i.sql
#done

