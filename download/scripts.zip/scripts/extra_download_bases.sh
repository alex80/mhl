#!/bin/bash
#-------------------------------------------------------------------------------------------------------------------
#  Donwload bases
#-------------------------------------------------------------------------------------------------------------------

source config.sh


for i in $tables_fb
do
	curl $url/$i.sql.gz -o $sql_path_fb/$i.sql.gz
done

#for i in $tables_es
#do
#	curl $url_es/$i.sql.gz -o $sql_path_es/$i.sql.gz
#done


