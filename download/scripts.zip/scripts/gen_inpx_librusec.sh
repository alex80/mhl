#!/bin/bash
#-------------------------------------------------------------------------------------------------------------------
# Генерирует файлы базы для создания коллекции LibRuSec, от 0 до $End в файле gen_inpx_librusec.php
#-------------------------------------------------------------------------------------------------------------------

source config.sh


name="librusec_online_fb2"


cd $tmp_path

rm $result_path/$name.info
rm $result_path/$name.ver
rm $result_path/$name.inpx
rm $result_path/$name.zip

cp $script_path/collection.info.es $tmp_path/collection.info

php $script_path/gen_inpx_librusec.php $user $pass $result_path $name

rm $tmp_path/*

chown www-data $result_path/$name.info
chown www-data $result_path/$name.zip
chown www-data $result_path/$name.ver

chmod 666 $result_path/$name.info
chmod 666 $result_path/$name.zip
chmod 666 $result_path/$name.ver

cp $result_path/$name.zip $result_path/$name.inpx

